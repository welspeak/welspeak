const API = {
  slots:"/api/slots",
  tickets:"/api/tickets",
  create:"/api/ticket",
  count:"/api/count",
  exit:id=>`/api/exit/${id}`,
  history:"/api/history"
};

async function loadSlots(){
  const res = await fetch(API.slots); const slots = await res.json();
  const grid = document.getElementById("slotsGrid"); grid.innerHTML="";
  let free=0; slots.forEach(s=>{
    const d = document.createElement("div"); d.className="slot "+(s.occupied?"occupied":"free"); d.innerText=s.slot;
    grid.appendChild(d); if(!s.occupied) free++;
  });
  document.getElementById("slotsInfo").innerText=`${free} free slots`;
}

async function loadTickets(){
  const res = await fetch(API.tickets); const rows=await res.json();
  const tbody=document.querySelector("#ticketsTable tbody"); tbody.innerHTML="";
  rows.forEach(r=>{
    const tr=document.createElement("tr");
    tr.innerHTML=`<td>${r.id}</td><td>${r.plate}</td><td>${r.slot}</td><td>${new Date(r.time_in).toLocaleString()}</td>
    <td><button onclick="exitTicket(${r.id})">Exit</button></td>`;
    tbody.appendChild(tr);
  });
}

async function loadCount(){
  const res = await fetch(API.count); const data=await res.json();
  document.getElementById("count").innerText=`${data.count} vehicle(s) inside`;
}

async function createTicket(){
  const plate=document.getElementById("plate").value.trim();
  const desired=document.getElementById("desiredSlot").value;
  if(!plate){alert("Enter plate");return;}
  const res = await fetch(API.create,{
    method:"POST", headers:{"Content-Type":"application/json"},
    body:JSON.stringify({plate,desiredSlot:desired})
  });
  const data=await res.json(); if(data.error){alert(data.error);return;}
  alert(`Ticket #${data.id} created at slot ${data.slot}`);
  loadSlots(); loadTickets(); loadCount();
}

async function exitTicket(id){
  if(!confirm("Confirm exit?")) return;
  const res=await fetch(API.exit(id),{method:"POST"}); const data=await res.json();
  alert(`Exited. Fee: ₱${data.fee}`);
  loadSlots(); loadTickets(); loadCount();
}

// init
loadSlots(); loadTickets(); loadCount();

// Dark mode toggle
const darkToggle=document.getElementById('darkToggle');
darkToggle.addEventListener('change',e=>{
  document.body.classList.toggle('dark',e.target.checked);
  localStorage.setItem('dark',e.target.checked?'1':'0');
});
if(localStorage.getItem('dark')==='1'){
  darkToggle.checked=true;
  document.body.classList.add('dark');
}


// Populate tickets table
async function loadTickets() {
  const res = await fetch("/api/tickets");
  const rows = await res.json();
  const tbody = document.querySelector("#ticketsTable tbody");
  tbody.innerHTML = "";

  rows.forEach(r => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${r.id}</td>
      <td>${r.plate}</td>
      <td>${r.slot}</td>
      <td>${new Date(r.time_in).toLocaleString()}</td>
      <td>
        <button onclick="showQR(${r.id})">QR</button>
        <button onclick="exitTicket(${r.id})">Exit</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

// Show QR code in new window
async function showQR(id){
  const res = await fetch(`/api/ticket/${id}/qr`);
  const data = await res.json();
  const w = window.open("", "_blank");
  w.document.write(`<h3>Ticket ID: ${id}</h3><img src="${data.qr}">`);
}
