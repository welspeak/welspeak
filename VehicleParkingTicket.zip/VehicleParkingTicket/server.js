const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const QRCode = require("qrcode");

const app = express();
app.use(express.json());
app.use(express.static("public"));

const DB_FILE = "./parking.db";
const FEE_PER_HOUR = 20;
const ADMIN_USER = "admin";
const ADMIN_PASS = "1234";

const db = new sqlite3.Database(DB_FILE);

// --- Init tables ---
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS slots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slot TEXT UNIQUE,
    occupied INTEGER DEFAULT 0
  );`);

  db.run(`CREATE TABLE IF NOT EXISTS tickets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    plate TEXT,
    slot TEXT,
    time_in TEXT
  );`);

  db.run(`CREATE TABLE IF NOT EXISTS history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    plate TEXT,
    slot TEXT,
    time_in TEXT,
    time_out TEXT,
    fee REAL
  );`);

  db.get("SELECT COUNT(*) AS c FROM slots", (err, row) => {
    if (row.c === 0) {
      const slots = [];
      for (let r = 1; r <= 5; r++) {
        const rowName = String.fromCharCode(64 + r);
        for (let c = 1; c <= 4; c++) slots.push(`${rowName}${c}`);
      }
      const stmt = db.prepare("INSERT INTO slots (slot, occupied) VALUES (?,0)");
      slots.forEach(s=>stmt.run(s));
      stmt.finalize();
    }
  });
});

function nowISO() { return new Date().toISOString(); }

// --- Admin login ---
app.post("/login", (req,res)=>{
  const {user,pass}=req.body;
  if(user===ADMIN_USER && pass===ADMIN_PASS) return res.json({success:true});
  res.json({success:false});
});

// --- API routes ---
app.get("/api/slots",(req,res)=>{
  db.all("SELECT * FROM slots ORDER BY slot",(err,rows)=>res.json(rows));
});

app.get("/api/tickets",(req,res)=>{
  db.all("SELECT * FROM tickets ORDER BY id DESC",(err,rows)=>res.json(rows));
});

app.get("/api/count",(req,res)=>{
  db.get("SELECT COUNT(*) AS c FROM tickets",(err,row)=>res.json({count:row.c}));
});

app.post("/api/ticket",(req,res)=>{
  const {plate, desiredSlot}=req.body;
  if(!plate) return res.status(400).json({error:"Plate required"});
  const assign=(slot)=>{
    const t=nowISO();
    db.run("INSERT INTO tickets (plate, slot, time_in) VALUES (?,?,?)",[plate,slot,t],function(err){
      db.run("UPDATE slots SET occupied=1 WHERE slot=?",[slot]);
      res.json({id:this.lastID,plate,slot,time_in:t});
    });
  };
  if(desiredSlot){
    db.get("SELECT * FROM slots WHERE slot=?",[desiredSlot],(err,row)=>{
      if(!row || row.occupied) return res.status(400).json({error:"Slot unavailable"});
      assign(desiredSlot);
    });
  } else {
    db.get("SELECT * FROM slots WHERE occupied=0 ORDER BY slot LIMIT 1",(err,row)=>{
      if(!row) return res.status(400).json({error:"Parking full"});
      assign(row.slot);
    });
  }
});

app.post("/api/exit/:id",(req,res)=>{
  const id=req.params.id;
  db.get("SELECT * FROM tickets WHERE id=?",[id],(err,ticket)=>{
    if(!ticket) return res.status(404).json({error:"Ticket not found"});
    const ms = new Date() - new Date(ticket.time_in);
    const hours = Math.ceil(ms / (1000*60*60));
    const fee = hours*FEE_PER_HOUR;
    const timeOut = nowISO();
    db.run("INSERT INTO history (plate, slot, time_in, time_out, fee) VALUES (?,?,?,?,?)",
      [ticket.plate,ticket.slot,ticket.time_in,timeOut,fee]);
    db.run("DELETE FROM tickets WHERE id=?",[id]);
    db.run("UPDATE slots SET occupied=0 WHERE slot=?",[ticket.slot]);
    res.json({hours,fee,time_out:timeOut});
  });
});

app.get("/api/history",(req,res)=>{
  db.all("SELECT * FROM history ORDER BY id DESC",(err,rows)=>res.json(rows));
});

app.get("/api/ticket/:id/qr", async(req,res)=>{
  const id=req.params.id;
  db.get("SELECT * FROM tickets WHERE id=?",[id],async(err,ticket)=>{
    if(!ticket) return res.status(404).json({error:"Ticket not found"});
    const payload={id:ticket.id,plate:ticket.plate,slot:ticket.slot,time_in:ticket.time_in};
    const qr=await QRCode.toDataURL(JSON.stringify(payload));
    res.json({qr});
  });
});

app.listen(3000,()=>console.log("Server running at http://localhost:3000"));

async function showQR(id){
  const res = await fetch(`/api/ticket/${id}/qr`);
  const data = await res.json();
  const w=window.open(""); w.document.write(`<img src="${data.qr}">`);
}
