package com.assessment.sasing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SasingApplicationTests {

	@Test
	void contextLoads() {
	}

}
