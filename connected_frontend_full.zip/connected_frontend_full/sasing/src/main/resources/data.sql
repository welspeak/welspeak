INSERT INTO app_user (username, password, role, name) VALUES
('teacher1', 'teachpass', 'TEACHER', 'Mr. Teacher'),
('student1', 'studpass', 'STUDENT', 'John Student');
