Connected Front-end (full)
Instructions:
1. Place these files in a folder and run a static server (VSCode Live Server recommended) e.g. http://127.0.0.1:5500
2. Ensure backend Spring Boot is running at http://localhost:8080 (the API_URL in api.js)
3. Login with sample accounts: student1 / studpass  OR teacher1 / teachpass
4. If your backend returns numeric user id in login, it will be saved; otherwise the front-end uses a default mapping (student1->2, teacher1->1) or prompts for id when needed.
