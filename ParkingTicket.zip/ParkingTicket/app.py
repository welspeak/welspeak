from flask import Flask, render_template, request, redirect, url_for
import qrcode
import base64
from io import BytesIO
from datetime import datetime

app = Flask(__name__)

# In-memory ticket storage
tickets = {}
ticket_id = 1

# Generate QR code as Base64 image
def generate_qr(data):
    qr = qrcode.make(data)
    buffer = BytesIO()
    qr.save(buffer, format="PNG")
    qr_b64 = base64.b64encode(buffer.getvalue()).decode()
    return "data:image/png;base64," + qr_b64

# Home page: create ticket
@app.route("/")
def home():
    return render_template("index.html")

# Create ticket
@app.route("/create_ticket", methods=["POST"])
def create_ticket():
    global ticket_id
    plate = request.form.get("plate")
    entry_time = datetime.now()

    ticket = {
        "id": ticket_id,
        "plate": plate,
        "entry_time": entry_time,
        "exit_time": None,
        "fee": 0,
        "status": "UNPAID",
        "qr": generate_qr(str(ticket_id))
    }

    tickets[ticket_id] = ticket
    ticket_id += 1

    return redirect(url_for("view_ticket", id=ticket["id"]))

# View ticket
@app.route("/ticket/<int:id>")
def view_ticket(id):
    ticket = tickets.get(id)
    if not ticket:
        return "Ticket not found"
    return render_template("view_ticket.html", t=ticket)

# Exit and pay
@app.route("/ticket/<int:id>/pay")
def pay_ticket(id):
    ticket = tickets.get(id)
    if not ticket:
        return "Ticket not found"

    ticket["exit_time"] = datetime.now()

    # Compute fee: ₱20 first 2h, ₱10 per additional hour
    hours = (ticket["exit_time"] - ticket["entry_time"]).total_seconds() / 3600
    if hours <= 2:
        fee = 20
    else:
        fee = 20 + int(hours - 2 + 1) * 10

    ticket["fee"] = fee
    ticket["status"] = "PAID"

    return render_template("pay_ticket.html", t=ticket)

# Run server directly
if __name__ == "__main__":
    app.run(debug=True)
